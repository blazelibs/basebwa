TemplatingBWC
=============

.. image:: https://ci.appveyor.com/api/projects/status/bhpcl30hw36y6wyi?svg=true
    :target: https://ci.appveyor.com/project/level12/templatingbwc

.. image:: https://circleci.com/gh/blazelibs/templatingbwc.svg?style=shield
    :target: https://circleci.com/gh/blazelibs/templatingbwc

.. image:: https://codecov.io/gh/blazelibs/templatingbwc/branch/master/graph/badge.svg
  Â Â :target: https://codecov.io/gh/blazelibs/templatingbwc

Introduction
---------------

TemplatingBWC is a component for `BlazeWeb <http://pypi.python.org/pypi/BlazeWeb/>`_
applications.  Its main purpose is to provide a customizable yet generic
template appropriate for back-end, control-panel, or similiar use-oriented web
applications.

Questions & Comments
---------------------

Please visit: http://groups.google.com/group/blazelibs

Current Status
---------------

The code stays pretty stable, but the API may change in the future.

The `TemplatingBWC tip <https://github.com/blazelibs/templatingbwc/archive/master.zip#egg=templatingbwc-dev>`_
is installable via `easy_install` with ``easy_install TemplatingBWC==dev``.


Change Log
----------


0.4.0 released 2016-11-29
===========================

* Add support for Python 3 (3.4 and 3.5)
* Set up continuous integration testing on CircleCI and AppVeyor
* Test coverage is on CodeCov

0.3.1 released 2014-09-18
===========================

* BC break: updated jQuery to latest 1.x version (1.11.1)
* updates related to jQuery: jQuery-UI, Superfish, HoverIntent
* jQuery-UI css now monolithic, jquery_ui_links macro deprecated
* Select2 updated to 3.5.1
* removed webgrid-specific CSS (relevant styles are in webgrid)
* updated image-link text-indents which would be problematic for wide displays

0.3.0 released 2014-08-20
===========================

* adding Select2 UI element
* updating jquery libs while maintaining compatibility with older UI elements
  such as Multiselect
* add "head_end" to admin template for easily adding tags to end of HTML head


0.2.1/2 released 2014-07-14
===========================

* fixed submit button left margin on admin template forms.  Was 110px but needed
  to be 160px to match the label + margin.
* add css to make cancel buttons look like a link


