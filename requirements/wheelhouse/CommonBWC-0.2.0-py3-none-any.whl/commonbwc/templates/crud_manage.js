
$(document).ready(function() {
   $(".delete_link").click(function() {
     return confirm("Delete this item?");
   });
 });
