$(document).ready(function() {
    $('select[multiple="multiple"]').select2({
        'width': '400px',
        'placeholder': 'Select option(s)',
        'closeOnSelect': false
    });
});
