.. ChangeLog & News
.. some thoughts on the format & content:
.. https://profiles.google.com/109440316880874537119/posts/ZBxGKEsMGRe

Changelog
=========

0.2 -- <UNRELEASED>
-------------------

* comment
* feature #123: added foobar widget (also #176, #185)
* bug #124:


0.1 -- 2011-01-01
-----------------

* Another Example
